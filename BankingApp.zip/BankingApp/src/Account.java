
import java.util.Scanner;

public class Account {

	// Declarations

	int balance;
	int previousTransaction;
	int choice;
	int choice2;

	void deposit(int amount) {

		if (amount != 0) {

			System.out.println("You have successfully deposited" + " " + "R" + amount + " " + "into your account");

			balance = balance + amount;
			previousTransaction = amount;
		}

	}
	
	void welcome() {

		System.out.println("Welcome to ProBank");
		System.out.println();

	}

	void BuyMenu() {

		System.out.println("What would you like to buy?");
		System.out.println("1 - Airtime");
		System.out.println("2 - Electricity");
		System.out.println("3 - Go back to Main Menu");

	}
	
	void payment() {

		System.out.println("-----------------Options----------------");
		System.out.println("1- Send money using cellphone numbers");
		System.out.println("2- Pay someone using thier Account number");
		System.out.println("3- Bill payment");
		System.out.println("4- Go back to Main Menu");

	}

	

	void withdraw(int amount) {

		if (amount > balance) {

			System.out.println("Insufficient funds");

			balance = balance;
			previousTransaction = previousTransaction;

		} else if (amount <= balance) {

			System.out.println("Withdrawal of" + " " + "R" +  amount + " " + "was successfull");

			balance = balance - amount;
			previousTransaction = -amount;
		}
	}

	void previousTransaction() {

		if (previousTransaction > 0) {

			System.out.println("Deposited:" + previousTransaction);

		} else if (previousTransaction < 0) {

			System.out.println("Withdrawn:" + previousTransaction);

		} else

			System.out.println("No Transaction was made");

	}

	void airtime() {

		Scanner input = new Scanner(System.in);

		if (choice == 1) {

			System.out.println("Choose your Network Provider:");
			System.out.println("------------------------------");
			System.out.println("1- Vodacom");
			System.out.println("2- TelkomMobile");
			System.out.println("3- CellC");
			System.out.println("4- MTN");
			System.out.println("5- BoxerCom");
			System.out.println("6- Go back to Main Menu");

			choice2 = input.nextInt();

			if (choice2 == 1) {

				System.out.println("Enter Amount:");
				int airtimeAmount = input.nextInt();

				if (airtimeAmount > balance) {

					System.out.println("Insufficient Funds");

					System.out.println();

					menu();

				} else

					System.out.println("Cellphone number:");
				int cellNum = input.nextInt();

				System.out.println("---------------------------------------------------------------------");
				System.out.println("Airtime  of R" + airtimeAmount + " " + "to this number" + " " + "+27" + cellNum
						+ " " + " was successfully purchased");
				System.out.println("----------------------------------------------------------------------");

				balance = balance - airtimeAmount;

				System.out.println();

			}

			if (choice2 == 2) {

				System.out.println("Enter Amount:");
				int airtimeAmount = input.nextInt();

				if (airtimeAmount > balance) {

					System.out.println("Insufficient Funds");

					System.out.println();

					menu();

				} else

					System.out.println("Cellphone number:");
				int cellNum = input.nextInt();

				System.out.println("---------------------------------------------------------------------");
				System.out.println("Airtime  of R" + airtimeAmount + " " + "to this number" + " " + "+27" + cellNum
						+ " " + " was successfully purchased");
				System.out.println("----------------------------------------------------------------------");

				balance = balance - airtimeAmount;

				System.out.println();
			}

			if (choice2 == 3) {

				System.out.println("Enter Amount:");
				int airtimeAmount = input.nextInt();

				if (airtimeAmount > balance) {

					System.out.println("Insufficient Funds");

					System.out.println();

					menu();

				} else

					System.out.println("Cellphone number:");
				int cellNum = input.nextInt();

				System.out.println("-----------------------------------------------------------------------");
				System.out.println("Airtime  of R" + airtimeAmount + " " + "to this number" + " " + "+27" + cellNum
						+ " " + " was successfully purchased");
				System.out.println("-----------------------------------------------------------------------");

				balance = balance - airtimeAmount;

				System.out.println();
			}

			if (choice2 == 4) {

				System.out.println("Enter Amount:");
				int airtimeAmount = input.nextInt();

				if (airtimeAmount > balance) {

					System.out.println("Insufficient Funds");

					System.out.println();

					menu();

				} else

					System.out.println("Cellphone number:");
				int cellNum = input.nextInt();

				System.out.println("----------------------------------------------------------------------");
				System.out.println("Airtime  of R" + airtimeAmount + " " + "to this number" + " " + "+27" + cellNum
						+ " " + " was successfully purchased");
				System.out.println("-----------------------------------------------------------------------");

				balance = balance - airtimeAmount;

				System.out.println();
			}

			if (choice2 == 5) {

				System.out.println("Enter Amount:");
				int airtimeAmount = input.nextInt();

				if (airtimeAmount > balance) {

					System.out.println("Insufficient Funds");

					System.out.println();

					menu();

				} else

					System.out.println("Cellphone number:");
				int cellNum = input.nextInt();

				System.out.println("---------------------------------------------------------------------");
				System.out.println("Airtime  of R" + airtimeAmount + " " + "to this number" + " " + "+27" + cellNum
						+ " " + " was successfully purchased");
				System.out.println("---------------------------------------------------------------------");

				balance = balance - airtimeAmount;

				System.out.println();
			}

			if (choice2 == 6) {

				menu();

			}
		}

	}

	void electricity() {

		Scanner input = new Scanner(System.in);

		System.out.print("Enter Meter Number:");
		int meterNum = input.nextInt();

		System.out.print("Amount:");
		int elecAmount = input.nextInt();

		if (elecAmount > balance) {

			System.out.println("Insufficient Funds");

			System.out.println();

			menu();

		} else

			System.out.println("------------------------------------------------------------------------");
		System.out.println("Electricity of" + " " + "R" + elecAmount + " " + "to this meter number" + " " + "#"
				+ meterNum + " " + "was successfully purchased");
		System.out.println("-------------------------------------------------------------------------");

		balance = balance - elecAmount;
	}

	void investment(int principalAmount, int period) {

		double rate = 0.10;

		double amountWithInterest = principalAmount * rate * period;
		
		double newAmount = principalAmount + amountWithInterest;

		balance = balance;

		previousTransaction = +principalAmount;

		System.out.println("------------------------------------------------------------------");
		System.out.println("Cuurent rate is 0.30%");
		
		System.out.println();

		System.out.println("In" + " " + period + " " + "Years" + " " + "the principal amount with interest will be " + " "
				+ "R" + newAmount);

		System.out.println("------------------------------------------------------------------");

	}

	

	void menu() {

		char option = '\0';
		Scanner input = new Scanner(System.in);

		System.out.println("What would you like to do?");
		System.out.println("---------------------------------");
		System.out.println("A - Check Account Balance");
		System.out.println("B - Make a cash Deposit");
		System.out.println("C - Make a cash Withdrawal");
		System.out.println("D - View Previous Transaction");
		System.out.println("E - Invest");
		System.out.println("F - Buy");
		System.out.println("G - Pay Someone");
		System.out.println("H - Exit");
		System.out.println("---------------------------------");

		do {

			System.out.println();
			System.out.print("Enter an Option:");
			char option1 = input.next().charAt(0);
			option = Character.toUpperCase(option1);
			System.out.println();

			switch (option) {

			case 'A':
				System.out.println("---------------------------------");
				System.out.println("Your Balance is" + " " + "R" + balance);
				System.out.println("---------------------------------");
				System.out.println();
				menu();
				break;

			case 'B':
				System.out.println("How much would you like to deposit?");
				int amount = input.nextInt();
				deposit(amount);
				System.out.println();
				menu();
				break;

			case 'C':
				System.out.println("How much would you like to Withdraw?");
				int amount2 = input.nextInt();
				withdraw(amount2);
				System.out.println();
				menu();
				break;

			case 'D':
				System.out.println("***************************");
				previousTransaction();
				System.out.println("**************************");
				System.out.println();
				menu();
				break;

			case 'E':
				System.out.println("How much would you like to invest with ProBank?");
				int principalAmount = input.nextInt();

				if (principalAmount >= balance) {

					System.out.println("You have insufficient funds in the acoount to make the investment");
					
					menu();

				} else if (principalAmount < balance) {

					System.out.println("How many Years would you like to invest your money with ProBank?");
					int period = input.nextInt();
					investment(principalAmount, period);

					System.out.println();

					System.out.println("Enter 1 to confirm investment or 2 to cancel investment");
					int choice = input.nextInt();

					if (choice == 1) {

						System.out.println("Investment confimed. Thank you for banking with ProBank");

						balance = balance - principalAmount;

						System.out.println();

						menu();
						break;

					} else if (choice == 2) {

						System.out.println("Investment cancelled.Thank you for banking with ProBank ");

						System.out.println();

						menu();
						break;

					}

				}

			case 'F':

				BuyMenu();

				choice = input.nextInt();

				if (choice == 1) {

					airtime();
				}

				if (choice == 2) {

					electricity();
				}

				if (choice == 3) {

					menu();
				}

				System.out.println();

				menu();
				break;

			case 'G':

				payment();
				int Choice = input.nextInt();

				if (Choice == 1) {

					System.out.print("Enter the cellphone number:");
					int cellNum = input.nextInt();

					System.out.print("Enter the Amount you want to pay:");
					System.out.println();
					int payment = input.nextInt();

					if (payment > balance) {

						System.out.println("Insufficient funds in the account");
						System.out.println();

						menu();
						input.nextInt();

					} else if (payment <= balance) {

						System.out.println(
								"----------------------------------------------------------------------------");
						System.out.println("Amount of " + "R" + payment + " " + "was sent successfully to this number"
								+ " " + "+27" + cellNum);
						System.out.println(
								"----------------------------------------------------------------------------");
						System.out.println();

						balance = balance - payment;

						menu();
						input.nextInt();

					}

				}

				if (Choice == 2) {

					System.out.print("Enter the Account number:");
					Long accNum = input.nextLong();

					System.out.print("Enter the Amount you want to pay:");
					System.out.println();
					int payment2 = input.nextInt();

					if (payment2 > balance) {

						System.out.println("Insufficient funds in the account");
						System.out.println();

						menu();
						input.nextInt();

					} else if (payment2 <= balance) {

						System.out.println(
								"----------------------------------------------------------------------------");
						System.out.println("Amount of " + "R" + payment2 + " "
								+ "was sent successfully to this Account number" + " " + accNum);
						System.out.println(
								"----------------------------------------------------------------------------");
						System.out.println();

						balance = balance - payment2;

						menu();
						input.nextInt();
				
					}
					
					
				}
				
				if(Choice == 3) {
					
					System.out.println("COMING SOON");
					System.out.println("G ");
					
					menu();
					input.nextInt();
				}
				
				
			}
			
			
						
		} while (option != 'H');
		System.out.println("Thank You for banking with ProBank");
		System.exit(0);

	}

}
