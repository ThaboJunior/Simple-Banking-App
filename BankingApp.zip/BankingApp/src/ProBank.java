
public class ProBank {

	public static void main(String[] args) {
		
		
		Account thabo = new Account();
		
		thabo.welcome();
		
		thabo.menu();

	}

}
